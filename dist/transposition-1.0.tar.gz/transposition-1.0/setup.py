from setuptools import setup

setup(
    name='transposition',
    version='1.0',
    description='',
    author='',
    author_email='',
    url='',
    packages=['solution'],
    include_package_data=True,
    zip_safe=False
)